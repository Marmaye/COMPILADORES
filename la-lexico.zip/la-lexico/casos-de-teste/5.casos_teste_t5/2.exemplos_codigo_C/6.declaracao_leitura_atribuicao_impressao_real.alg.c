/*
  Declaracao de duas variaveis do tipo real, leitura de uma, atribuicao com soma e impressao do valor resultante
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	float x, y;
	scanf("%f",&x);
	y = x + 5.0;
	printf("%f",y);
	return 0;
}
