/*
  Declaracao de duas variaveis do tipo real, leitura de seus valores e impressao do resultado da soma de ambas
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	float x, y;
	scanf("%f",&x);
	scanf("%f",&y);
	printf("%f",x+y);
	return 0;
}
